lwIP for Win32

This is a quickly hacked port of the lwIP library to Win32.

The code base used is the 0.5.3 release.
Added are the proj/msvc6 and the src/arch/msvc6 directorys.
Modified are src/netif/arp.c and src/include/ipv4/lwip/ip_addr.h.

Included in the proj/msvc6 directory is the network interface driver using
the winpcap library. In the src/arch/msvc6 directory is a simple single
threaded sys_arch implementation.

There is no documentation yet. Try to figure it out yourself.
This is provided as is, it's just a hack to test some stuff, no serious
implementation.

Florian Schulze (florian.proff.schulze@gmx.net)

lwIP: http://www.sics.se/~adam/lwip/
WinPCap: http://netgroup-serv.polito.it/winpcap/